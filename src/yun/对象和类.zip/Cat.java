package yun.对象和类;

/**
 * FileName: Cat
 * Date: 2020/11/6 15:24
 * Author:cs
 * Description:小猫类
 * class开头的就是类,本类就是Cat类
 */
public class Cat {
}
