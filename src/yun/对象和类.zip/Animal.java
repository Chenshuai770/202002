package yun.对象和类;

/**
 * FileName: Main
 * Date: 2020/11/6 15:23
 * Author:cs
 * Description:动物类
 * class开头的就是类,本类就是Animal类
 */
public class Animal {

}
